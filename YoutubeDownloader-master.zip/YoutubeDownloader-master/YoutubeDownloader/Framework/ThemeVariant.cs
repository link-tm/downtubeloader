﻿namespace YoutubeDownloader.Framework;

public enum ThemeVariant
{
    System,
    Light,
    Dark
}
