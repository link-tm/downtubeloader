using YoutubeDownloader.Framework;
using YoutubeDownloader.ViewModels.Dialogs;

namespace YoutubeDownloader.Views.Dialogs;

public partial class MessageBoxView : UserControl<MessageBoxViewModel>
{
    public MessageBoxView() => InitializeComponent();
}
