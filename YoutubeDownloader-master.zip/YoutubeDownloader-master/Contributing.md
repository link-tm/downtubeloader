# Contributing

## Building from source

### Requirements

- Windows, Linux, or macOS machine
- Latest [.NET SDK](https://dotnet.microsoft.com/download)
- Latest [PowerShell (`pwsh`)](https://learn.microsoft.com/powershell/scripting/install/installing-powershell)
- (Recommended) .NET IDE such as Visual Studio or JetBrains Rider
